from flask import Flask, request, jsonify
import openai

app = Flask(__name__)

# Set your OpenAI API key
openai.api_key = 'your-openai-api-key'

# Define a function to call the ChatGPT-4 model
def call_chatgpt4(prompt):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=prompt,
        temperature=0.7,
        max_tokens=150
    )
    return response.choices[0].text.strip()

# Define a route to handle incoming requests
@app.route('/ask', methods=['POST'])
def ask():
    data = request.json
    prompt = data['prompt']
    response = call_chatgpt4(prompt)
    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)
