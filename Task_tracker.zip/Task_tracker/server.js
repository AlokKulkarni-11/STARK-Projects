// server.js

const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to parse JSON bodies
app.use(bodyParser.json());

// Endpoint to handle POST requests for saving data from the Data Tracking section
app.post('/api/data-tracking', (req, res) => {
  const dataItem = req.body;

  // Here you would save the dataItem to your database or perform any necessary operations
  // For demonstration, we'll just log the received dataItem to the console
  console.log('Received data:', dataItem);

  // Respond with a success message
  res.status(200).json({ message: 'Data saved successfully' });
});

// Endpoint to handle POST requests for saving tasks from the To-Do Tasks section
app.post('/api/tasks', (req, res) => {
  const task = req.body.task;

  // Here you would save the task to your database or perform any necessary operations
  // For demonstration, we'll just log the received task to the console
  console.log('Received task:', task);

  // Respond with a success message
  res.status(200).json({ message: 'Task saved successfully' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
