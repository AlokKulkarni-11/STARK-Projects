// Function to save task item (AJAX call to server)
function saveTask(taskItem) {
    fetch('/api/tasks', { // Modify the URL to match your server endpoint
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(taskItem)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to save task');
      }
      return response.json();
    })
    .then(data => {
      console.log('Task saved successfully:', data);
      // Optionally, update UI or perform other actions after successful task save
      // Refresh the task list after saving
      fetchTasks();
    })
    .catch(error => {
      console.error('Error saving task:', error);
      // Optionally, display an error message or handle the error in some way
    });
  }
  
  // Function to fetch tasks from the server
  function fetchTasks() {
    fetch('/api/tasks') // Modify the URL to match your server endpoint
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch tasks');
        }
        return response.json();
      })
      .then(data => {
        // Display the fetched tasks in the UI
        const taskList = document.getElementById('task-list');
        taskList.innerHTML = ''; // Clear previous tasks
        data.forEach(task => {
          const listItem = document.createElement('li');
          listItem.textContent = task.description;
          taskList.appendChild(listItem);
        });
      })
      .catch(error => {
        console.error('Error fetching tasks:', error);
        // Optionally, display an error message or handle the error in some way
      });
  }
  
  // Event listener for submitting the task form
  document.getElementById('to-do-tasks-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
  
    // Get form data
    const taskDescription = document.getElementById('task').value;
  
    // Validate form data
    if (taskDescription.trim() === '') {
      alert('Please enter a task description.');
      return;
    }
  
    // Create task item object
    const taskItem = {
      description: taskDescription
    };
  
    // Save task item
    saveTask(taskItem);
  });
  
  // Function to save link (AJAX call to server)
  function saveLink(link) {
    fetch('/api/links', { // Modify the URL to match your server endpoint
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ link })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to save link');
      }
      return response.json();
    })
    .then(data => {
      console.log('Link saved successfully:', data);
      // Optionally, update UI or perform other actions after successful link save
      // Refresh the saved links list after saving
      fetchSavedLinks();
    })
    .catch(error => {
      console.error('Error saving link:', error);
      // Optionally, display an error message or handle the error in some way
    });
  }
  
  // Function to fetch saved links from the server
  function fetchSavedLinks() {
    fetch('/api/links') // Modify the URL to match your server endpoint
      .then(response => {
        if (!response.ok) {
          throw new Error('Failed to fetch links');
        }
        return response.json();
      })
      .then(data => {
        // Display the fetched links in the UI
        const savedLinks = document.getElementById('saved-links');
        savedLinks.innerHTML = ''; // Clear previous links
        data.forEach(link => {
          const linkItem = document.createElement('div');
          linkItem.textContent = link;
          savedLinks.appendChild(linkItem);
        });
      })
      .catch(error => {
        console.error('Error fetching links:', error);
        // Optionally, display an error message or handle the error in some way
      });
  }
  
  // Event listener for submitting the link form
  document.getElementById('saving-data-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission
  
    // Get form data
    const link = document.getElementById('link').value;
  
    // Validate form data
    if (link.trim() === '') {
      alert('Please enter a link.');
      return;
    }
  
    // Save link
    saveLink(link);
  });
  
  // Initial fetch of tasks and saved links when the page loads
  fetchTasks();
  fetchSavedLinks();
  
  // Function to save data item (AJAX call to server)
  function saveDataItem(dataItem) {
    fetch('/api/data-tracking', { // Modify the URL to match your server endpoint
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(dataItem)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Failed to save data');
      }
      return response.json();
    })
    .then(data => {
      console.log('Data saved successfully:', data);
      // Update the UI to reflect the saved data
      updateCodingDataList(dataItem);
    })
    .catch(error => {
      console.error('Error saving data:', error);
    });
  }
  
  // Function to update the coding data list with new entry
  function updateCodingDataList(dataItem) {
    const codingDataList = document.getElementById('coding-data-list');
  
    // Create a new paragraph element to display the saved data
    const newDataEntry = document.createElement('p');
    newDataEntry.textContent = `Time: ${dataItem.time} hours | Learnings: ${dataItem.learnings}`;
  
    // Append the new data entry to the coding data list
    codingDataList.appendChild(newDataEntry);
  }
  
  // Event listener for data tracking form submission
  document.getElementById('data-tracking-form').addEventListener('submit', function(event) {
    event.preventDefault();
  
    // Get the values from the form fields
    const timeSpent = parseFloat(document.getElementById('time').value);
    const learnings = document.getElementById('learnings').value;
  
    // Create a data item object
    const dataItem = {
      time: timeSpent,
      learnings: learnings
    };
  
    // Save the data item
    saveDataItem(dataItem);
  
    // Clear the form fields
    document.getElementById('time').value = '';
    document.getElementById('learnings').value = '';
  });
  