import React, { useState } from 'react';

const PortfolioForm = ({ onAdd }) => {
    const [name, setName] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        onAdd(name);
        setName('');
    };

    return (
        <form onSubmit={handleSubmit}>
            <input 
                type="text" 
                placeholder="Portfolio Name" 
                value={name} 
                onChange={(e) => setName(e.target.value)} 
                required 
            />
            <button type="submit">Add Portfolio</button>
        </form>
    );
};

export default PortfolioForm;
