import React, { useState } from 'react';
import Navbar from './navbar';
import PortfolioList from './PortfolioList';
import PortfolioForm from '.PortfolioForm';
import PortfolioDetail from './PortfolioDetail';
import './App.css';

const App = () => {
    const [portfolios, setPortfolios] = useState([]);
    const [selectedPortfolioId, setSelectedPortfolioId] = useState(null);
    const [theme, setTheme] = useState('light');

    const addPortfolio = (name) => {
        const newPortfolio = { id: portfolios.length + 1, name, investments: [] };
        setPortfolios([...portfolios, newPortfolio]);
    };

    const deletePortfolio = (id) => {
        setPortfolios(portfolios.filter(p => p.id !== id));
        if (selectedPortfolioId === id) setSelectedPortfolioId(null);
    };

    const addInvestment = (portfolioId, investment) => {
        setPortfolios(portfolios.map(p => 
            p.id === portfolioId ? { ...p, investments: [...p.investments, investment] } : p
        ));
    };

    const toggleTheme = () => {
        const newTheme = theme === 'light' ? 'dark' : 'light';
        setTheme(newTheme);
        document.documentElement.setAttribute('data-theme', newTheme);
    };

    return (
        <div className="App">
            <Navbar toggleTheme={toggleTheme} />
            <div className="container">
                <PortfolioForm onAdd={addPortfolio} />
                <PortfolioList 
                    portfolios={portfolios} 
                    onSelect={setSelectedPortfolioId} 
                    onDelete={deletePortfolio} 
                />
                {selectedPortfolioId && 
                    <PortfolioDetail 
                        portfolio={portfolios.find(p => p.id === selectedPortfolioId)} 
                        onAddInvestment={addInvestment} 
                    />
                }
            </div>
        </div>
    );
};

export default App;
