import React from 'react';
import { Pie, Line } from 'react-chartjs-2';
import { calculatePortfolioMetrics } from '../utils/calculations';

const Charts = ({ investments }) => {
    const assetAllocationData = {
        labels: investments.map(inv => inv.name),
        datasets: [{
            data: investments.map(inv => inv.amount),
            backgroundColor: ['#ff6384', '#36a2eb', '#cc65fe', '#ffce56', '#ff6384']
        }]
    };

    const performanceData = {
        labels: investments.map(inv => inv.date),
        datasets: [{
            label: 'Portfolio Value',
            data: investments.map(inv => inv.amount),
            fill: false,
            backgroundColor: 'rgb(75, 192, 192)',
            borderColor: 'rgba(75, 192, 192, 0.2)'
        }]
    };

    const { sharpeRatio, standardDeviation } = calculatePortfolioMetrics(investments);

    return (
        <div className="charts">
            <h3>Asset Allocation</h3>
            <Pie data={assetAllocationData} />

            <h3>Performance Over Time</h3>
            <Line data={performanceData} />

            <h3>Portfolio Metrics</h3>
            <p>Sharpe Ratio: {sharpeRatio}</p>
            <p>Standard Deviation: {standardDeviation}</p>
        </div>
    );
};

export default Charts;
