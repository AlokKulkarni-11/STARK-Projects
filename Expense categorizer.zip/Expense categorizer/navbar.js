import React from 'react';

const Navbar = ({ toggleTheme }) => {
    return (
        <nav className="navbar">
            <h1>Investment Portfolio Analyzer</h1>
            <button onClick={toggleTheme}>Toggle Theme</button>
        </nav>
    );
};

export default Navbar;
