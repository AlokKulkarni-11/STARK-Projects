export const calculatePortfolioMetrics = (investments) => {
    // Example calculations
    const totalReturn = investments.reduce((acc, inv) => acc + inv.amount, 0);
    const sharpeRatio = totalReturn / investments.length; // Simplified example
    const standardDeviation = Math.sqrt(investments.map(inv => Math.pow(inv.amount - totalReturn / investments.length, 2)).reduce((a, b) => a + b) / investments.length);

    return { sharpeRatio, standardDeviation };
};
