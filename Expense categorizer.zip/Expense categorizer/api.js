import axios from 'axios';

const API_URL = 'https://api.example.com';

export const fetchFinancialData = async (symbol) => {
    const response = await axios.get(`${API_URL}/financial-data/${symbol}`);
    return response.data;
};
