import React from 'react';
import InvestmentForm from './InvestmentForm';
import Charts from './Charts';

const PortfolioDetail = ({ portfolio, onAddInvestment }) => {
    return (
        <div className="portfolio-detail">
            <h2>{portfolio.name}</h2>
            <InvestmentForm onAdd={(investment) => onAddInvestment(portfolio.id, investment)} />
            <Charts investments={portfolio.investments} />
        </div>
    );
};

export default PortfolioDetail;
