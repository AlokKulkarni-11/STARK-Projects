import React from 'react';

const PortfolioList = ({ portfolios, onSelect, onDelete }) => {
    return (
        <div className="portfolio-list">
            <h2>Your Portfolios</h2>
            <ul>
                {portfolios.map(portfolio => (
                    <li key={portfolio.id}>
                        <span onClick={() => onSelect(portfolio.id)}>{portfolio.name}</span>
                        <button onClick={() => onDelete(portfolio.id)}>Delete</button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default PortfolioList;
