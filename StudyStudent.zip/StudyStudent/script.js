document.addEventListener('DOMContentLoaded', function () {
    // Task Manager
    const taskForm = document.getElementById('task-form');
    const taskList = document.getElementById('task-list');

    taskForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const taskInput = document.getElementById('task').value;
        if (taskInput.trim()) {
            const listItem = document.createElement('li');
            listItem.textContent = taskInput;
            taskList.appendChild(listItem);
            taskForm.reset();
        } else {
            alert('Please enter a task.');
        }
    });

    // Coding Progress
    document.getElementById('progress-form').addEventListener('submit', function (event) {
        event.preventDefault();
        const hours = parseFloat(document.getElementById('hours').value);
        const tasks = parseInt(document.getElementById('tasks').value);
        const projects = parseInt(document.getElementById('projects').value);
        const progressDisplay = document.getElementById('progress-display');
        progressDisplay.innerHTML = `<p>Hours Spent: ${hours}</p><p>Tasks Completed: ${tasks}</p><p>Projects Worked On: ${projects}</p>`;
        this.reset();
    });

    // Dark/Light Theme Toggle
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    });

    // Apply saved theme on load
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }

    // Search functionality
    const searchInput = document.getElementById('search');
    searchInput.addEventListener('input', function () {
        const query = this.value.toLowerCase();
        const cards = document.querySelectorAll('.card');
        cards.forEach(card => {
            const content = card.textContent.toLowerCase();
            card.style.display = content.includes(query) ? 'block' : 'none';
        });
    });
});
