document.addEventListener('DOMContentLoaded', function() {
    // Task Manager
    const taskForm = document.getElementById('task-form');
    const taskList = document.getElementById('task-list');
  
    taskForm.addEventListener('submit', function(event) {
      event.preventDefault();
      const taskInput = document.getElementById('task').value;
      if (taskInput.trim() !== '') {
        addTask(taskInput);
        taskForm.reset();
      } else {
        alert('Please enter a task description.');
      }
    });
  
    function addTask(taskDescription) {
      const listItem = document.createElement('li');
      listItem.textContent = taskDescription;
      taskList.appendChild(listItem);
    }
  
    // Coding Progress Tracker
    const codingStats = document.getElementById('coding-stats');
  
    // Function to update coding progress statistics
    function updateCodingStats() {
      // Implement logic to calculate coding progress statistics
      // Example: lines of code written, projects completed, time spent coding
      const codingStatistics = {
        linesOfCode: 1000,
        projectsCompleted: 5,
        timeSpentCoding: '10 hours'
      };
  
      // Update the DOM with the coding statistics
      codingStats.innerHTML = `
        <p>Lines of Code: ${codingStatistics.linesOfCode}</p>
        <p>Projects Completed: ${codingStatistics.projectsCompleted}</p>
        <p>Time Spent Coding: ${codingStatistics.timeSpentCoding}</p>
      `;
    }
  
    updateCodingStats(); // Call the function to initially display coding statistics
  
    // Content Saving
    const linkForm = document.getElementById('link-form');
    const savedLinks = document.getElementById('saved-links');
  
    linkForm.addEventListener('submit', function(event) {
      event.preventDefault();
      const linkInput = document.getElementById('link').value;
      if (linkInput.trim() !== '') {
        saveLink(linkInput);
        linkForm.reset();
      } else {
        alert('Please enter a link.');
      }
    });
  
    function saveLink(link) {
      const linkItem = document.createElement('div');
      linkItem.innerHTML = `Saved Link: <a href="${link}" target="_blank">${link}</a>`;
      savedLinks.appendChild(linkItem);
    }
  
    // Search Functionality
    const searchForm = document.getElementById('search-form');
    const searchResults = document.getElementById('search-results');
  
    searchForm.addEventListener('submit', function(event) {
      event.preventDefault();
      const searchTerm = document.getElementById('search').value;
      if (searchTerm.trim() !== '') {
        search(searchTerm);
        searchForm.reset();
      } else {
        alert('Please enter a search term.');
      }
    });
  
    function search(term) {
      // Implement search functionality
      // Display search results in the searchResults section
      // Example: search through tasks, saved links, etc.
      // Update the DOM with the search results
      searchResults.innerHTML = `
        <p>Search Results:</p>
        <p>No results found for "${term}".</p>
      `;
    }
  });

  document.getElementById('progress-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission
    
    // Get input values
    const hours = parseFloat(document.getElementById('hours').value);
    const tasks = parseInt(document.getElementById('tasks').value);
    const projects = parseInt(document.getElementById('projects').value);
    
    // Validate input (optional)
    if (isNaN(hours) || isNaN(tasks) || isNaN(projects)) {
      alert('Please enter valid numbers for hours, tasks, and projects.');
      return;
    }
    
    // Update progress display
    const progressDisplay = document.getElementById('progress-display');
    progressDisplay.innerHTML = `
      <p>Hours Spent Coding: ${hours}</p>
      <p>Tasks Completed: ${tasks}</p>
      <p>Projects Worked On: ${projects}</p>
    `;
    
    // Clear form fields
    document.getElementById('hours').value = '';
    document.getElementById('tasks').value = '';
    document.getElementById('projects').value = '';
  });