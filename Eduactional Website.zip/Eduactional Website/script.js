// Filter Courses by Difficulty
function filterCourses(difficulty) {
    const courses = [
        { 
            title: "Intro to Programming", 
            difficulty: "beginner", 
            description: "Learn the basics of programming with hands-on examples.",
            image: "course_placeholder.jpg"  // Replace with your image
        },
        { 
            title: "Advanced Web Development", 
            difficulty: "advanced", 
            description: "Master the latest web development frameworks and tools.",
            image: "course_placeholder.jpg"  // Replace with your image
        },
        { 
            title: "Data Science 101", 
            difficulty: "intermediate", 
            description: "Learn the basics of data science and analytics using Python.",
            image: "course_placeholder.jpg"  // Replace with your image
        },
    ];

    // Filter courses based on selected difficulty
    const filteredCourses = courses.filter(course => course.difficulty === difficulty);

    const coursesList = document.getElementById('courses-list');
    coursesList.innerHTML = ''; // Clear previous courses

    // Add filtered courses to the page
    filteredCourses.forEach(course => {
        const courseCard = `
            <div class="col-md-4">
                <div class="card">
                    <img src="${course.image}" class="card-img-top" alt="${course.title}" loading="lazy">
                    <div class="card-body">
                        <h5 class="card-title">${course.title}</h5>
                        <p class="card-text">${course.description}</p>
                        <a href="course_detail.html" class="btn btn-primary">Learn More</a>
                    </div>
                </div>
            </div>
        `;
        coursesList.innerHTML += courseCard;
    });
}

// Optional: You can call this function for the default state when the page loads
window.onload = function() {
    // Default view: Show all courses or filter by "beginner" as default
    filterCourses('beginner');
}
