document.addEventListener("DOMContentLoaded", () => {
    const taskInput = document.getElementById("taskInput");
    const addButton = document.getElementById("addButton");
    const taskList = document.getElementById("taskList");

    // Function to add a task
    function addTask() {
        const taskText = taskInput.value.trim();
        
        if (taskText === "") return;  // Don't add empty tasks
        
        const li = document.createElement("li");
        li.textContent = taskText;

        // Create a remove button for each task
        const removeButton = document.createElement("button");
        removeButton.textContent = "Remove";
        removeButton.classList.add("remove");
        removeButton.onclick = () => {
            li.remove();  // Remove the task when clicked
        };

        li.appendChild(removeButton);
        taskList.appendChild(li);
        taskInput.value = "";  // Clear input field after adding
    }

    // Add task when 'Add' button is clicked
    addButton.addEventListener("click", addTask);

    // Add task when 'Enter' key is pressed
    taskInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            addTask();
        }
    });
});
